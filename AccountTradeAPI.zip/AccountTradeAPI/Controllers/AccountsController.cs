using System;
using System.Diagnostics;
using System.Threading.Tasks;
using AccountTradeAPI.Data;
using AccountTradeAPI.Models;
using AccountTradeAPI.Repositories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;

namespace AccountTradeAPI.Controllers
{
    [ApiController]
    [Route("api/accounts")]
    public class AccountsController : ControllerBase
    {
        //private readonly AppDbContext _context;
        private readonly IMemoryCache _cache;
        private readonly IAccountRepository _repository;

        public AccountsController(IMemoryCache cache, IAccountRepository repository)
        {
            //_context = context;
            _repository = repository ?? throw new ArgumentNullException(nameof(repository));
            _cache = cache ?? throw new ArgumentNullException(nameof(cache));
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(Guid id)
        {

            // Check Cache First
            if (!_cache.TryGetValue(id, out Account account))
            {
                // If the account is not in the cache, query the database
                account = await _repository.GetByIdAsync(id);  // This assumes you have a repository layer

                if (account == null)
                {
                    return NotFound();
                }

                // Store the result in the cache for subsequent requests
                _cache.Set(id, account, new MemoryCacheEntryOptions
                {
                    AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(5), // Cache expires in 5 minutes
                    SlidingExpiration = TimeSpan.FromMinutes(2), // Cache slides every 2 minutes
                    AbsoluteExpiration = DateTimeOffset.UtcNow.AddMinutes(10)
                });
            }

            return Ok(account);


            //var account = await _repository.GetByIdAsync(id);
            //return account == null ? NotFound() : Ok(account);
        }

        [HttpGet("search")]
        public async Task<IActionResult> SearchByLastName([FromQuery] string lastName)
        {
            //var accounts = await _repository.SearchByLastNameAsync(lastName);
            // Cache Key: Search by Last Name
            var cacheKey = $"accounts_search_{lastName}";

            if (!_cache.TryGetValue(cacheKey, out IQueryable<Account> accounts))
            {
                // If cache miss, query the database
                accounts = (IQueryable<Account>?)await _repository.SearchByLastNameAsync(lastName); // Assuming you have a method like this

                // Store the result in the cache for subsequent requests
                _cache.Set(cacheKey, accounts, new MemoryCacheEntryOptions
                {
                    AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(10) // Cache expires in 10 minutes
                });
            }

            return Ok(accounts);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Account account)
        {
            if (account == null || string.IsNullOrWhiteSpace(account.FirstName) || string.IsNullOrWhiteSpace(account.LastName))
                return BadRequest("Invalid account details.");


            // Validate Trades (if provided)
            if (account.Trades != null && account.Trades.Any())
            {
                var validationError = ValidateTrades(account.Trades);
                if (validationError != null)
                    return BadRequest(validationError);
            }

            account.Id = Guid.NewGuid();
            await _repository.AddAsync(account);
            await _repository.SaveAsync();
            return CreatedAtAction(nameof(GetById), new { id = account.Id }, account);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(Guid id)
        {
            var account = await _repository.GetByIdAsync(id);

            if (account == null)
                return NotFound("Account not found.");

            await _repository.DeleteAsync(account);
            await _repository.SaveAsync();

            return NoContent(); // 204 No Content
        }


        private string? ValidateTrades(IEnumerable<Trade> trades)
        {
            foreach (var trade in trades)
            {
                if (!Enum.IsDefined(typeof(TradeStatus), trade.Status))
                    return "Invalid status.";

                if (trade.Amount <= 0)
                    return "Invalid trade amount. Amount must be greater than zero.";
            }
            return null; // No validation errors
        }


    }
}
