﻿using System;
using System.Threading.Tasks;
using AccountTradeAPI.Models;
using AccountTradeAPI.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace AccountTradeAPI.Controllers
{
    [ApiController]
    [Route("api/trades")]
    public class TradesController : ControllerBase
    {
        private readonly ITradeRepository _repository;

        public TradesController(ITradeRepository repository)
        {
            _repository = repository;
        }

        [HttpPost]
        public async Task<IActionResult> PlaceTrade([FromBody] Trade trade)
        {
            if (trade == null || string.IsNullOrWhiteSpace(trade.SecurityCode) || trade.Amount <= 0)
                return BadRequest("Invalid trade details.");

            trade.Id = Guid.NewGuid();
            trade.Timestamp = DateTime.UtcNow;
            trade.Status = TradeStatus.Placed;

            await _repository.AddAsync(trade);
            await _repository.SaveAsync();

            return CreatedAtAction(nameof(GetTradeById), new { id = trade.Id }, trade);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetTradeById(Guid id)
        {
            var trade = await _repository.GetByIdAsync(id);
            return trade == null ? NotFound() : Ok(trade);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateTradeStatus(Guid id, [FromBody] string status)
        {
            // Validate that the status is one of the defined enum values
            if (!Enum.TryParse(status, out TradeStatus parsedStatus) || !Enum.IsDefined(typeof(TradeStatus), parsedStatus))
            {
                return BadRequest("Invalid status.");
            }

            var trade = await _repository.GetByIdAsync(id);
            if (trade == null)
                return NotFound();

            trade.Status = parsedStatus;
            await _repository.UpdateAsync(trade);
            await _repository.SaveAsync();

            return Ok(trade);
        }
    }
}
