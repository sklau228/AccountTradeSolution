﻿using AccountTradeAPI.Controllers;
using AccountTradeAPI.Data;
using AccountTradeAPI.Models;
using Microsoft.EntityFrameworkCore;
namespace AccountTradeAPI.Services;

public class AccountService
{
    private readonly AppDbContext _context;

    public AccountService(AppDbContext context)
    {
        _context = context;
    }

    public async Task<List<Account>> GetAccountsAsync()
    {
        return await _context.Accounts.ToListAsync();
    }

    public async Task<Account?> GetAccountByIdAsync(int id)
    {
        return await _context.Accounts.FindAsync(id);
    }

    public async Task CreateAccountAsync(Account account)
    {
        _context.Accounts.Add(account);
        await _context.SaveChangesAsync();
    }

    public async Task<bool> DeleteAccountAsync(int id)
    {
        var account = await _context.Accounts.FindAsync(id);
        if (account == null) return false;
        _context.Accounts.Remove(account);
        await _context.SaveChangesAsync();
        return true;
    }
}
