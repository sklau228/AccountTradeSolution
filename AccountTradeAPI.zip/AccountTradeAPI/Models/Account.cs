﻿using System.ComponentModel.DataAnnotations;

namespace AccountTradeAPI.Models
{
    public class Account
    {
        [Key]
        public Guid Id { get; set; }

        [Required]
        public string FirstName { get; set; }

        [Required]
        public string LastName { get; set; }

        public ICollection<Trade> Trades { get; set; } = new List<Trade>();
    }
}
