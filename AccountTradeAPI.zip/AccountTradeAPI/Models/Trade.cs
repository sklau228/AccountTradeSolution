﻿using System.ComponentModel.DataAnnotations;

namespace AccountTradeAPI.Models
{
    public class Trade
    {
        [Key]
        public Guid Id { get; set; }

        [Required]
        public Guid AccountId { get; set; }

        [Required, StringLength(3)]
        public string SecurityCode { get; set; }

        public DateTime Timestamp { get; set; }

        [Required]
        public decimal Amount { get; set; }

        [Required]
        public string BuyOrSell { get; set; }

        [Required]
        public TradeStatus Status { get; set; }

        // Navigation property for EF relationship
        public Account Account { get; set; }
    }

    public enum TradeStatus
    {
        Placed,
        Executed,
        Expired
    }
}
