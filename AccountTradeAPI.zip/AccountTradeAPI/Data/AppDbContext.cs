﻿using AccountTradeAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace AccountTradeAPI.Data
{
    public class AppDbContext : DbContext
    {
        private IConfiguration _configuration;

        public AppDbContext(DbContextOptions<AppDbContext> options, IConfiguration configuration)
            : base(options)
        {
            _configuration = configuration;
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {

            _configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory()) // Sets the correct path
                .AddJsonFile("appsettings.json") // Load testing config
                .Build();

            if (_configuration.GetValue<bool>("UseInMemoryDatabase"))
            {
                optionsBuilder.UseInMemoryDatabase("TestDatabase");
            }
            else
            {
                optionsBuilder.UseNpgsql(_configuration.GetConnectionString("DefaultConnection"));
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Account>()
                .HasMany(a => a.Trades)
                .WithOne(t => t.Account)
                .HasForeignKey(t => t.AccountId)
                .OnDelete(DeleteBehavior.Cascade); // Ensures trades are deleted automatically
        }

        public DbSet<Account> Accounts { get; set; }
        public DbSet<Trade> Trades { get; set; }
    }
}
