﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AccountTradeAPI.Models;

namespace AccountTradeAPI.Repositories
{
    public interface ITradeRepository
    {
        Task<Trade> GetByIdAsync(Guid id);
        Task<IEnumerable<Trade>> GetTradesByAccountIdAsync(Guid accountId);
        Task AddAsync(Trade trade);
        Task UpdateAsync(Trade trade);
        Task SaveAsync();
    }
}
