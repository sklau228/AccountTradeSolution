﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AccountTradeAPI.Data;
using AccountTradeAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace AccountTradeAPI.Repositories
{
    public class TradeRepository : ITradeRepository
    {
        private readonly AppDbContext _context;

        public TradeRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<Trade> GetByIdAsync(Guid id) => await _context.Trades.FindAsync(id);

        public async Task<IEnumerable<Trade>> GetTradesByAccountIdAsync(Guid accountId) =>
            await _context.Trades.Where(t => t.AccountId == accountId).ToListAsync();

        public async Task AddAsync(Trade trade)
        {
            await _context.Trades.AddAsync(trade);
        }

        public async Task UpdateAsync(Trade trade)
        {
            _context.Trades.Update(trade);
        }

        public async Task SaveAsync()
        {
            await _context.SaveChangesAsync();
        }
    }
}
