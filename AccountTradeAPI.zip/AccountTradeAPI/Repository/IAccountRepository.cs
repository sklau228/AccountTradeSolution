﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AccountTradeAPI.Models;

namespace AccountTradeAPI.Repositories
{
    public interface IAccountRepository
    {
        Task<Account> GetByIdAsync(Guid id);
        Task<IEnumerable<Account>> SearchByLastNameAsync(string lastName);
        Task AddAsync(Account account);
        Task SaveAsync();
        Task DeleteAsync(Account account);
    }
}