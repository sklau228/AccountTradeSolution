﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AccountTradeAPI.Data;
using AccountTradeAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace AccountTradeAPI.Repositories
{
    public class AccountRepository : IAccountRepository
    {
        private readonly AppDbContext _context;

        public AccountRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<Account> GetByIdAsync(Guid id) =>
            await _context.Accounts.Include(a => a.Trades).FirstOrDefaultAsync(a => a.Id == id);

        public async Task<IEnumerable<Account>> SearchByLastNameAsync(string lastName) =>
            await _context.Accounts.Where(a => a.LastName == lastName).ToListAsync();

        public async Task AddAsync(Account account)
        {
            await _context.Accounts.AddAsync(account);
        }

        public async Task SaveAsync()
        {
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(Account account)
        {
            _context.Accounts.Remove(account);
        }
    }
}
