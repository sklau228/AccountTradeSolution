﻿using System;
using System.Threading.Tasks;
using AccountTradeAPI.Controllers;
using AccountTradeAPI.Data;
using AccountTradeAPI.Models;
using AccountTradeAPI.Repositories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Xunit;

public class TradesControllerTests
{
    private AppDbContext GetInMemoryDbContext()
    {
        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase(databaseName: "TestDb")
            .Options;

        var context = new AppDbContext(options,null);
        context.Database.EnsureCreated();
        return context;
    }

    [Fact]
    public async Task PlaceTrade_ShouldReturnCreatedTrade()
    {
        var context = GetInMemoryDbContext();
        var repository = new TradeRepository(context);
        var controller = new TradesController(repository);

        var newTrade = new Trade { AccountId = Guid.NewGuid(), SecurityCode = "AAPL", Amount = 1000, BuyOrSell = "Buy" };

        var result = await controller.PlaceTrade(newTrade);

        var createdResult = Assert.IsType<CreatedAtActionResult>(result);
        var trade = Assert.IsType<Trade>(createdResult.Value);
        Assert.Equal("AAPL", trade.SecurityCode);
    }

    [Fact]
    public async Task GetTradeById_ShouldReturnTrade_WhenExists()
    {
        var context = GetInMemoryDbContext();
        var repository = new TradeRepository(context);
        var controller = new TradesController(repository);

        var trade = new Trade { Id = Guid.NewGuid(), AccountId = Guid.NewGuid(), SecurityCode = "TSLA", Amount = 1500, BuyOrSell = "Sell", Status = TradeStatus.Expired };
        await repository.AddAsync(trade);
        await repository.SaveAsync();

        var result = await controller.GetTradeById(trade.Id);

        var okResult = Assert.IsType<OkObjectResult>(result);
        var returnedTrade = Assert.IsType<Trade>(okResult.Value);
        Assert.Equal(trade.Id, returnedTrade.Id);
    }
}
