﻿using AccountTradeAPI.Controllers;
using AccountTradeAPI.Data;
using AccountTradeAPI.Models;
using AccountTradeAPI.Repositories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Moq;

public class AccountsControllerTests
{
    private AppDbContext GetInMemoryDbContext()
    {
        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase(databaseName: "TestDb")
            .Options;

        var context = new AppDbContext(options,null);
        context.Database.EnsureCreated();
        return context;
    }

    [Fact]
    public async Task CreateAccount_ShouldReturnCreatedAccount()
    {
        var context = GetInMemoryDbContext();
        var repository = new AccountRepository(context);
        var mockCache = new Mock<IMemoryCache>();

        var controller = new AccountsController(mockCache.Object,repository); // Inject mock cache

        //var controller = new AccountsController(repository);

        var newAccount = new Account { FirstName = "John", LastName = "Doe" };

        var result = await controller.Create(newAccount);

        var createdResult = Assert.IsType<CreatedAtActionResult>(result);
        var account = Assert.IsType<Account>(createdResult.Value);
        Assert.Equal("John", account.FirstName);
    }

    [Fact]
    public async Task GetById_ShouldReturnAccount_WhenExists()
    {
        var context = GetInMemoryDbContext();
        var repository = new AccountRepository(context);
        //var controller = new AccountsController(repository);
        var mockCache = new Mock<IMemoryCache>();

        var controller = new AccountsController(mockCache.Object, repository); // Inject mock cache


        var account = new Account { Id = Guid.NewGuid(), FirstName = "Alice", LastName = "Smith" };
        await repository.AddAsync(account);
        await repository.SaveAsync();

        var result = await controller.GetById(account.Id);

        var okResult = Assert.IsType<OkObjectResult>(result);
        var returnedAccount = Assert.IsType<Account>(okResult.Value);
        Assert.Equal(account.Id, returnedAccount.Id);
    }
}
